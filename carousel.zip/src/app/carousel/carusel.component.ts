import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

export interface Slide {
  title: string;
}

@Component({
  selector: 'app-carusel',
  templateUrl: './carusel.component.html',
  styleUrls: ['./carusel.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CaruselComponent implements OnInit {
  @Output() showClick = new EventEmitter();
  @Input() slides: Slide[];
  @Input() slidesToScroll = 3;
  groupedSlides: Slide[][];
  currentSlide = 0;

  constructor() { }

  ngOnInit() {
    this.groupedSlides = this.chunckArray(this.slides || []);
  }

  onNextClick() {
    const next = this.currentSlide + 1;
    this.currentSlide = next === this.groupedSlides.length ? 0 : next;
  }

  onPreviousClick() {
    const previous = this.currentSlide - 1;
    this.currentSlide = previous < 0 ? this.groupedSlides.length - 1 : previous;
  }

  onShowClick(slide) {
    const {title} = slide;
    this.showClick.emit(title);
  }

  chunckArray(arr, chunckLen = this.slidesToScroll) {
    const chuckedArr = [];
    for (const item of arr) {
      let last = chuckedArr[chuckedArr.length - 1];
      (!last || last.length === chunckLen) ? chuckedArr.push([item]) : last.push(item);
    }
    return chuckedArr;
  }

}
